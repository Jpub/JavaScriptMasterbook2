var x = 30;
if (x >= 10) {
  if (x >= 20) {
    console.log('변수 x는 20이상이다.');
  } else {
    console.log('변수 x는 10이상 20미만이다');
  }
} else {
  console.log('변수 x는 10미만이다.');
}
