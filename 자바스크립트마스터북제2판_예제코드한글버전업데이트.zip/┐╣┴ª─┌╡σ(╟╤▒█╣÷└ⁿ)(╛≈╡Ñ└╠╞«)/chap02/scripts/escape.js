window.alert('안녕하세요. JavaScript！\n열심히 공부합시다.');
