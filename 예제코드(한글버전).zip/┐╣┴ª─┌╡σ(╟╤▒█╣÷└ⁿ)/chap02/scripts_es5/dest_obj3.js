'use strict';

var book = { title: 'Java포켓 레퍼런스', publish: '기술평론사' };
var name = book.title;
var company = book.publish;


console.log(name);
console.log(company);
