var flag = new Boolean(false);

if (flag) {
  console.log('flag는 true입니다!');
}