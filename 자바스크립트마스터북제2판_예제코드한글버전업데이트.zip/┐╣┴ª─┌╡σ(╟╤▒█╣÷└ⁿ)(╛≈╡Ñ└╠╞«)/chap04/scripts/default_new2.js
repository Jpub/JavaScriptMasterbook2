function multi(a, b = a) {
  return a * b; 
}
console.log(multi(10, 5));
console.log(multi(3));
