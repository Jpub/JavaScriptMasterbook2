'use strict';

var msg = void 0;

var x = void 0,
    y = void 0;

var greeting = '안녕하세요, 자바스크립트！';

console.log(greeting);
