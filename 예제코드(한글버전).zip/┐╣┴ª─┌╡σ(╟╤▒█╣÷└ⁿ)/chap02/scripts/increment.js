var x = 3;
var y = x++;
console.log(x);
console.log(y);

var x = 3;
var y = ++x;
console.log(x);
console.log(y);
