'use strict';

var name = '하은';
var str = '안녕하세요,' + name + '씨.\n오늘도 좋은 날씨네요!';
console.log(str);
