'use strict';

var name = '김성룡';
var birth = new Date(1970, 5, 25);
var member = { name: name, birth: birth };

console.log(member);
