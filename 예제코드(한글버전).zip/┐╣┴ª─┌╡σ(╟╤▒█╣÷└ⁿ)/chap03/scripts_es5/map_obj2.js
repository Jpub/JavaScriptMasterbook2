'use strict';

var key = {};
var m = new Map();
m.set(key, 'hoge');
console.log(m.get(key));
