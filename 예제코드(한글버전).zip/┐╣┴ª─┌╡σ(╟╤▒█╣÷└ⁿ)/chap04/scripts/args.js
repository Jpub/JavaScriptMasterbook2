function showMessage(value) {
  console.log(value);
}

showMessage();
showMessage('철수');
showMessage('철수', '영희');
