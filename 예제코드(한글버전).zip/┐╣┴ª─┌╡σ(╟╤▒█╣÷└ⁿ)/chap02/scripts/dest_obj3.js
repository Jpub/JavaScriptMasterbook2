let book = { title: 'Java포켓 레퍼런스', publish: '기술평론사' };
let { title: name, publish: company } = book;

console.log(name);
console.log(company);