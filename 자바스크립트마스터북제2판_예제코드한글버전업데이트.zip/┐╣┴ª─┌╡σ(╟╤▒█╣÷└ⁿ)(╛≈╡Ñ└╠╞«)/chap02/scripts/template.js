let name = '하은';
let str = `안녕하세요, ${name}씨.
오늘도 좋은 날씨네요!`;
console.log(str);
