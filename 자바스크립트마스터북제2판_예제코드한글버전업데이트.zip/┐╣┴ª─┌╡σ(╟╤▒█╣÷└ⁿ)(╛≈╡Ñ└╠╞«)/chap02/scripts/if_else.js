var x = 30;
if (x >= 20) {
  console.log('변수x는 20이상이다.');
} else if (x >= 10) {
  console.log('변수x는 10이상이다.');
} else {
  console.log('변수x는 10미만이다.');
}
