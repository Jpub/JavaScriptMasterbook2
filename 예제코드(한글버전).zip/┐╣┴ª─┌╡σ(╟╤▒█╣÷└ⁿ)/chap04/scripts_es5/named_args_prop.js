'use strict';

function show(_ref) {
  var name = _ref.name;

  console.log(name);
};

var member = {
  mid: 'Y0001',
  name: '정시온',
  address: 'shion_jung@example.com'
};

show(member);
