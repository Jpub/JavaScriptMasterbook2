import { Member as MyMember, Area as MyArea } from './lib/Util'

var m = new MyMember('성룡', '김');
console.log(m.getName());
console.log(MyArea.getTriangle(10, 5));
