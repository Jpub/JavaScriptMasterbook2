var str = '안녕하세요!';
// var str = new String('안녕하세요!');
console.log(str.length);
