var msg = '💩싸';
console.log(msg.length);
