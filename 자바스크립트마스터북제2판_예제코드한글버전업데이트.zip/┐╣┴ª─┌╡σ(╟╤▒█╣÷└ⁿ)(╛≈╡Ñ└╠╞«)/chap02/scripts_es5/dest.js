"use strict";

var data = [56, 40, 26, 82, 19, 17, 73, 99];
var x0 = data[0];
var x1 = data[1];
var x2 = data[2];
var x3 = data[3];
var x4 = data[4];
var x5 = data[5];
var x6 = data[6];
var x7 = data[7];


console.log(x0);
console.log(x1);
console.log(x2);
console.log(x3);
console.log(x4);
console.log(x5);
console.log(x6);
console.log(x7);
