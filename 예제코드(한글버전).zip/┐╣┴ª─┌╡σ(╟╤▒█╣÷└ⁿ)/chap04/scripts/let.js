if (true) {
  let i = 5;
}

console.log(i);
