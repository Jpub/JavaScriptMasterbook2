console.log('삼각형의 면적:' + getTriangle(5, 2));

var getTriangle = function(base, height) {
  return base * height / 2;
};
