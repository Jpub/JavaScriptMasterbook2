var msg = '';
msg = msg || '안녕하세요, 자바스크립트!';
console.log(msg);
