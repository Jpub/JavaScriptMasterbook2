function show(x, y = 1) {
  console.log('x = ' + x);
  console.log('y = ' + y);
}

show();
