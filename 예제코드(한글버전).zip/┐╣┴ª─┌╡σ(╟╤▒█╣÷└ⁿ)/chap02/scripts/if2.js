var x = 15;
if (x >= 10) {
  console.log('변수 x는 10이상이다.');
}
