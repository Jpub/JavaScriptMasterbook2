var x = 8;
do {
  console.log('x의 값은 ' + x);
  x++;
} while(x < 10);
