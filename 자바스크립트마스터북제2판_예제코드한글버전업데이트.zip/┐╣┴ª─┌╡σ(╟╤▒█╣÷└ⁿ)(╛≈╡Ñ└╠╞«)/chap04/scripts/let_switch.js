switch(x) {
  case 0:
    let value = 'x:0';
  case 1:
    let value = 'x:1';
}