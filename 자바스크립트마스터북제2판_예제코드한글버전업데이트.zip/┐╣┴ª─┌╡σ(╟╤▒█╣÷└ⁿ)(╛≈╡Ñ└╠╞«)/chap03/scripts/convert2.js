var num = 123;
console.log(!!num);
