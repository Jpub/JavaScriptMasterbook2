let msg;

let x, y;

let greeting = '안녕하세요、자바스크립트！';

console.log(greeting);