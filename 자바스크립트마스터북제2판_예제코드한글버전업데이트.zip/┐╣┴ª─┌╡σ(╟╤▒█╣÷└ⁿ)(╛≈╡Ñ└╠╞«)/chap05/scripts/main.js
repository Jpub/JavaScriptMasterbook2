import { Member, Area } from './lib/Util';

var m = new Member('성룡', '김');
console.log(m.getName());
