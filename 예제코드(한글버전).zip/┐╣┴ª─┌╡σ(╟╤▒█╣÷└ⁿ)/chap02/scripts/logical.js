var x = 1;
var y = 2;

console.log(x === 1 && y === 1);
console.log(x === 1 || y === 1);
