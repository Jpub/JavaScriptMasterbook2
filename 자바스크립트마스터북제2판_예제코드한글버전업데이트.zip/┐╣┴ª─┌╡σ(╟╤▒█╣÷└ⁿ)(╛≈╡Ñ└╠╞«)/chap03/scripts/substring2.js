var str = 'WINGS프로젝트';
console.log(str.substring(5, -2));
console.log(str.slice(5, -2));
