var x = 1;
var y = 2;
if (x === 1) {
  if (y === 1) {
    console.log('변수x、y는 모두 1이다.');
  }
} else {
  console.log('변수x는 1이 아니다.');
}
