console.log('삼각형의 면적:' + getTriangle(5, 2));

function getTriangle(base, height) {
  return base * height / 2;
}
