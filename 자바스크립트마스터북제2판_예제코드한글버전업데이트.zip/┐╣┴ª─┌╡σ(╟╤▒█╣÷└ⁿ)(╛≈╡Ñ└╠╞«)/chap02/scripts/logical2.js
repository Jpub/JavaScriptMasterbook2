var x = 1;

if (x === 1) { console.log('안녕하세요'); }
x ===1 && console.log('안녕하세요');
