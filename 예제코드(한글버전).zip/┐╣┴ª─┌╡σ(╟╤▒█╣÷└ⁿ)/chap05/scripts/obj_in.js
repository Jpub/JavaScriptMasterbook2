var obj = { hoge: function(){}, foo: function(){} };

console.log('hoge' in obj);
console.log('piyo' in obj);