let str = '💩쌌어요';
console.log(str.match(/^.쌌어요$/gu));