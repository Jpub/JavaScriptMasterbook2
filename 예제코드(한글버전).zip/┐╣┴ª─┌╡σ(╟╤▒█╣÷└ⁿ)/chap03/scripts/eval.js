var str = 'console.log("eval함수")';
eval(str);
