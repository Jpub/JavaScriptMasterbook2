function multi(a = b, b = 5) {
  return a * b; 
}

console.log(multi());
