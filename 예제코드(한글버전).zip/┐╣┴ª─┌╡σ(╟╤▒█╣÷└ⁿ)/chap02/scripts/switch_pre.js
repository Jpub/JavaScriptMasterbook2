var rank = 'B';
if (rank === 'A') {
  console.log('A랭크입니다.');
} else if (rank === 'B') {
  console.log('B랭크입니다.');
} else if (rank === 'C') {
  console.log('C랭크입니다.');
} else {
  console.log('아무 랭크도 아닙니다.');
}
