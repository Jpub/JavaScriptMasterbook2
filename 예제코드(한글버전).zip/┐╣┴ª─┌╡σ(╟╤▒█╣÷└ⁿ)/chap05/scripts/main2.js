import * as app from './lib/Util'

var m = new app.Member('성룡', '김');
console.log(m.getName());

