msg = '안녕하세요、JavaScript！';
console.log(msg);