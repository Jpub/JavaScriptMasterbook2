var rank = 'B';
switch(rank) {
  case 'A' :
  case 'B' :
  case 'C' :
    console.log('합격！');
    break;
  case 'D' :
    console.log('불합격...');
    break;
}
