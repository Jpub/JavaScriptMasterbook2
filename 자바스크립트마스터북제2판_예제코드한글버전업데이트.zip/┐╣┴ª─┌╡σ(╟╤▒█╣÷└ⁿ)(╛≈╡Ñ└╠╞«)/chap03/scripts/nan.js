console.log(Number.NaN === Number.NaN);
