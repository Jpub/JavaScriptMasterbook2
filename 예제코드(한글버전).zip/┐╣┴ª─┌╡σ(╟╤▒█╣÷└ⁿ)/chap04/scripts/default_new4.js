function getTriangle(base = 1, height) {
  return base * height / 2;
}

console.log(getTriangle(10));
