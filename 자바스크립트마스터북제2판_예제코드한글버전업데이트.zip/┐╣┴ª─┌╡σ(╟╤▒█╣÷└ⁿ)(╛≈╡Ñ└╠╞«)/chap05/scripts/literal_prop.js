let name = '김성룡';
let birth = new Date(1970, 5, 25);
let member = { name, birth };

console.log(member);
