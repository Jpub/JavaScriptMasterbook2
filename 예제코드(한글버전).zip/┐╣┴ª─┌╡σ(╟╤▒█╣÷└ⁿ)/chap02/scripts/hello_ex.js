// window.alert은, 지정된 문자열을 대화 상자 표시를 위한 명령이다.
window.alert('안녕하세요, 자바 스크립트!');