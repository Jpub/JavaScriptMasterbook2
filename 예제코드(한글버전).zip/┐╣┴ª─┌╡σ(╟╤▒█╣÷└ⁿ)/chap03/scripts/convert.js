console.log(typeof(123 + ''));
console.log(typeof('123' - 0));
